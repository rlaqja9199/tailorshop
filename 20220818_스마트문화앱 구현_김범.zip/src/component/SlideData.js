export const slideList = [
    {
        id: 1,
        linkImg: '/images/main1.jpg',
        body: '',
    },
    {
        id: 2,
        linkImg: '/images/main2.jpg',
        body: '',
    },
    {
        id: 3,
        linkImg: '/images/main3.jpg',
        body: '',
    },
    {
        id: 4,
        linkImg: '/images/main4.jpg',
        body: '',
    }
]