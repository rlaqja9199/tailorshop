import React from 'react'
import './Main.css'
import MainSlide from './MainSlide'

const Main = () => {
  return (
    <div id='main'>
        <MainSlide />
        <div></div>
    </div>
  )
}

export default Main